import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

def create_stock_chart(stock_data, symbol):
    """Create interactive stock price chart"""
    if stock_data is None or stock_data.empty:
        return None

    fig = make_subplots(rows=2, cols=1, 
                       shared_xaxes=True,
                       vertical_spacing=0.03,
                       subplot_titles=('Price', 'Volume'))

    # Candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=stock_data.index,
            open=stock_data['Open'],
            high=stock_data['High'],
            low=stock_data['Low'],
            close=stock_data['Close'],
            name='OHLC'
        ),
        row=1, col=1
    )

    # Volume bar chart
    fig.add_trace(
        go.Bar(
            x=stock_data.index,
            y=stock_data['Volume'],
            name='Volume'
        ),
        row=2, col=1
    )

    fig.update_layout(
        title=f'{symbol} Stock Price and Volume',
        yaxis_title='Price',
        yaxis2_title='Volume',
        xaxis_rangeslider_visible=False,
        height=800,
        xaxis=dict(
            type='date',
            tickformat='%Y-%m-%d',
            tickangle=45
        ),
        xaxis2=dict(
            type='date',
            tickformat='%Y-%m-%d',
            tickangle=45
        )
    )

    return fig

def create_sentiment_chart(sentiment_summary):
    """Create sentiment analysis pie chart"""
    labels = list(sentiment_summary.keys())
    values = list(sentiment_summary.values())

    fig = go.Figure(data=[go.Pie(labels=labels, values=values,
                                hole=.3,
                                marker_colors=['#2ecc71', '#95a5a6', '#e74c3c'])])

    fig.update_layout(
        title='News Sentiment Distribution',
        annotations=[dict(text='Sentiment', x=0.5, y=0.5, font_size=20, showarrow=False)]
    )

    return fig