import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import finnhub
import os

def get_stock_data(symbol, period='3mo'):
    """Fetch stock data from Yahoo Finance"""
    try:
        stock = yf.Ticker(symbol)
        hist = stock.history(period=period)
        info = stock.info
        return hist, info
    except Exception as e:
        print(f"Error fetching data for {symbol}: {str(e)}")
        return None, None

def get_competitors(symbol):
    """Get top 3 competitors for a given stock symbol"""
    try:
        stock = yf.Ticker(symbol)
        info = stock.info

        # Get competitors from Yahoo Finance
        competitors = []
        if 'companyOfficers' in info:  # This indicates we have company info
            sector = info.get('sector', '')
            industry = info.get('industry', '')
            market_cap = info.get('marketCap', 0)

            # Search for companies in the same industry
            if industry:
                search = yf.Tickers(symbol).tickers[symbol].financials
                similar_companies = yf.download(
                    group_by="ticker",
                    period="1d",
                    threads=True
                )

                # Filter and sort by market cap
                for comp in similar_companies.columns.levels[0]:
                    if comp != symbol:
                        comp_info = yf.Ticker(comp).info
                        if comp_info.get('industry') == industry:
                            competitors.append({
                                'symbol': comp,
                                'name': comp_info.get('shortName', comp),
                                'market_cap': comp_info.get('marketCap', 0)
                            })

                # Sort by market cap and get top 3
                competitors.sort(key=lambda x: x['market_cap'], reverse=True)
                competitors = competitors[:3]

        # If no competitors found through industry search, return some default competitors
        if not competitors:
            default_competitors = {
                'TECH': ['AAPL', 'MSFT', 'GOOGL'],
                'FINANCE': ['JPM', 'BAC', 'WFC'],
                'RETAIL': ['WMT', 'AMZN', 'TGT'],
                'AUTO': ['TSLA', 'GM', 'F'],
                'HEALTHCARE': ['JNJ', 'PFE', 'UNH']
            }
            sector = info.get('sector', 'TECH')
            comp_list = default_competitors.get(sector, ['AAPL', 'MSFT', 'GOOGL'])
            competitors = [{'symbol': s, 'name': s} for s in comp_list]

        return competitors
    except Exception as e:
        print(f"Error fetching competitors for {symbol}: {str(e)}")
        return []

def get_earnings_calendar(symbols):
    """Get earnings calendar for given symbols"""
    earnings_data = []
    for symbol in symbols:
        try:
            stock = yf.Ticker(symbol)
            calendar = stock.calendar
            if calendar is not None and not calendar.empty:
                earnings_data.append({
                    'Symbol': symbol,
                    'Earnings Date': calendar.iloc[0]['Earnings Date']
                })
        except:
            continue
    return pd.DataFrame(earnings_data)

def get_news_headlines(symbol):
    """Fetch news headlines using Finnhub API"""
    try:
        # Initialize Finnhub client
        finnhub_client = finnhub.Client(api_key=os.environ['FINNHUB_API_KEY'])

        # Get current date and date from 1 week ago
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)

        # Convert dates to UNIX timestamp
        from_timestamp = int(start_date.timestamp())
        to_timestamp = int(end_date.timestamp())

        # Fetch company news
        news = finnhub_client.company_news(symbol, _from=start_date.strftime('%Y-%m-%d'), 
                                         to=end_date.strftime('%Y-%m-%d'))

        if not news:
            print(f"No news found for {symbol}")
            return []

        # Process news data
        headlines = []
        for article in news[:10]:  # Get last 10 articles
            if article.get('headline') and article.get('datetime'):
                headlines.append({
                    'title': article['headline'],
                    'date': datetime.fromtimestamp(article['datetime']).strftime('%Y-%m-%d'),
                    'link': article.get('url', ''),
                    'source': article.get('source', '')
                })

        print(f"Found {len(headlines)} headlines for {symbol}")
        return headlines

    except Exception as e:
        print(f"Error fetching news for {symbol}: {str(e)}")
        return []