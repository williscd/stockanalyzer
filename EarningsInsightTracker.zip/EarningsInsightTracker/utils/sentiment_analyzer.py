from nltk.sentiment import SentimentIntensityAnalyzer
import nltk

# Download required NLTK data
try:
    nltk.data.find('vader_lexicon')
except LookupError:
    nltk.download('vader_lexicon')

def analyze_sentiment(headlines):
    """Analyze sentiment of news headlines"""
    if not headlines:
        return []

    sia = SentimentIntensityAnalyzer()
    sentiments = []

    for headline in headlines:
        # Skip invalid headlines
        if not headline.get('title') or not headline.get('date'):
            continue

        # Analyze sentiment
        scores = sia.polarity_scores(headline['title'])
        compound_score = scores['compound']

        # More conservative thresholds for classification
        if compound_score >= 0.2:
            sentiment = 'Positive'
        elif compound_score <= -0.2:
            sentiment = 'Negative'
        else:
            sentiment = 'Neutral'

        sentiments.append({
            'title': headline['title'],
            'date': headline['date'],
            'link': headline.get('link', ''),
            'source': headline.get('source', ''),
            'compound': round(compound_score, 3),
            'sentiment': sentiment
        })

    return sorted(sentiments, key=lambda x: x['date'], reverse=True)

def get_sentiment_summary(sentiments):
    """Get summary of sentiment analysis"""
    if not sentiments:
        return {'Positive': 0, 'Neutral': 0, 'Negative': 0}

    summary = {'Positive': 0, 'Neutral': 0, 'Negative': 0}
    for sentiment in sentiments:
        summary[sentiment['sentiment']] += 1
    return summary