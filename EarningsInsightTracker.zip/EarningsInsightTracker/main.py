import streamlit as st
import pandas as pd
from utils.data_fetcher import get_stock_data, get_news_headlines
from utils.sentiment_analyzer import analyze_sentiment, get_sentiment_summary
from utils.visualization import create_stock_chart, create_sentiment_chart

# Page configuration
st.set_page_config(page_title="Stock Analysis Tool", layout="wide")

# Title and description
st.title("📈 Stock Analysis Tool")
st.markdown("""
This tool provides stock analysis with news sentiment and price visualization.
Enter stock symbols with $ prefix (e.g., $AAPL, $MSFT, $BRK.B)
""")

# Input section with example placeholder
symbols_input = st.text_input(
    "Enter stock symbols (space-separated with $ prefix)",
    placeholder="$AAPL $MSFT $BRK.B",
    help="Enter symbols like $NVDA $HIMS $SOUN"
)

# Process symbols: remove $ prefix, strip whitespace, convert to uppercase
if symbols_input:
    symbols = [
        symbol.strip().upper().replace('$', '')
        for symbol in symbols_input.split()
        if symbol.strip().startswith('$')
    ]

    if not symbols:
        st.warning("Please enter valid stock symbols starting with $")
    else:
        # Display selected symbols
        st.info(f"Analyzing {len(symbols)} symbols: {', '.join(['$' + sym for sym in symbols])}")

        # Stock Analysis for each symbol
        for symbol in symbols:
            st.header(f"📊 Analysis for ${symbol}")

            with st.spinner(f"Fetching data for ${symbol}..."):
                # Fetch stock data
                stock_data, stock_info = get_stock_data(symbol)

                if stock_data is not None and stock_info is not None:
                    # Create two columns for layout
                    col1, col2 = st.columns([2, 1])

                    with col1:
                        # Stock price chart
                        st.subheader("Price Chart")
                        fig = create_stock_chart(stock_data, symbol)
                        st.plotly_chart(fig, use_container_width=True, key=f"price_chart_{symbol}")

                    with col2:
                        # Key metrics
                        st.subheader("Key Metrics")
                        metrics = {
                            'Market Cap': stock_info.get('marketCap', 'N/A'),
                            'P/E Ratio': stock_info.get('trailingPE', 'N/A'),
                            '52 Week High': stock_info.get('fiftyTwoWeekHigh', 'N/A'),
                            '52 Week Low': stock_info.get('fiftyTwoWeekLow', 'N/A')
                        }

                        metrics_df = pd.DataFrame({
                            'Metric': metrics.keys(),
                            'Value': [
                                f"${value:,.2f}" if isinstance(value, (int, float)) else str(value)
                                for value in metrics.values()
                            ]
                        })
                        st.table(metrics_df)

                    # News Sentiment Analysis
                    st.subheader("📰 News Sentiment Analysis")
                    with st.spinner(f"Analyzing news for ${symbol}..."):
                        news = get_news_headlines(symbol)

                        if news:
                            sentiments = analyze_sentiment(news)
                            if sentiments:
                                sentiment_summary = get_sentiment_summary(sentiments)

                                # Display sentiment distribution
                                fig_sentiment = create_sentiment_chart(sentiment_summary)
                                st.plotly_chart(fig_sentiment, use_container_width=True, key=f"sentiment_chart_{symbol}")

                                # Display news with sentiment
                                news_df = pd.DataFrame(sentiments)
                                st.dataframe(
                                    news_df[['date', 'source', 'title', 'sentiment', 'compound']],
                                    use_container_width=True,
                                    key=f"news_table_{symbol}"
                                )

                                # Download buttons
                                col1, col2 = st.columns(2)
                                with col1:
                                    csv = news_df.to_csv(index=False)
                                    st.download_button(
                                        label="Download News Data",
                                        data=csv,
                                        file_name=f"{symbol}_news_sentiment.csv",
                                        mime="text/csv",
                                        key=f"download_news_{symbol}"
                                    )
                                with col2:
                                    csv = stock_data.to_csv()
                                    st.download_button(
                                        label="Download Stock Data",
                                        data=csv,
                                        file_name=f"{symbol}_stock_data.csv",
                                        mime="text/csv",
                                        key=f"download_stock_{symbol}"
                                    )
                            else:
                                st.warning("No news headlines found for analysis")
                        else:
                            st.warning("Unable to fetch news. Please try again later.")
                else:
                    st.error(f"Error fetching data for ${symbol}")
else:
    st.info("Please enter at least one stock symbol to analyze")

# Footer
st.markdown("---")
st.markdown("Built with Streamlit, yfinance, and Finnhub API")