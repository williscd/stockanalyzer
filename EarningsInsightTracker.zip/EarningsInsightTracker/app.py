from flask import Flask, render_template, jsonify, request
from utils.data_fetcher import get_stock_data, get_news_headlines, get_competitors
from utils.sentiment_analyzer import analyze_sentiment, get_sentiment_summary
import json

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    symbols_input = data.get('symbols', '').strip()

    # Process symbols: remove $ prefix, strip whitespace, convert to uppercase
    symbols = [
        symbol.strip().upper().replace('$', '')
        for symbol in symbols_input.split()
        if symbol.strip().startswith('$')
    ]

    if not symbols:
        return jsonify({'error': 'Please enter valid stock symbols starting with $'})

    results = []
    for symbol in symbols:
        # Fetch stock data
        stock_data, stock_info = get_stock_data(symbol)
        if stock_data is None or stock_info is None:
            results.append({
                'symbol': symbol,
                'error': f'Error fetching data for ${symbol}'
            })
            continue

        # Get competitors
        competitors = get_competitors(symbol)

        # Get news and sentiment
        news = get_news_headlines(symbol)
        sentiments = analyze_sentiment(news) if news else []
        sentiment_summary = get_sentiment_summary(sentiments)

        # Prepare response
        results.append({
            'symbol': symbol,
            'success': True,
            'stock_data': {
                'dates': stock_data.index.strftime('%Y-%m-%d').tolist(),
                'prices': stock_data['Close'].tolist(),
                'volumes': stock_data['Volume'].tolist()
            },
            'metrics': {
                'Market Cap': stock_info.get('marketCap', 'N/A'),
                'P/E Ratio': stock_info.get('trailingPE', 'N/A'),
                '52 Week High': stock_info.get('fiftyTwoWeekHigh', 'N/A'),
                '52 Week Low': stock_info.get('fiftyTwoWeekLow', 'N/A')
            },
            'competitors': competitors,
            'news': sentiments,
            'sentiment_summary': sentiment_summary
        })

    return jsonify({'results': results})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)